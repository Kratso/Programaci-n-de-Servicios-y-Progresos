## Non-modular samples for IntelliJ

JavaFX 11 samples to run from IntelliJ with different options and build tools

Version IntelliJ IDEA 2018.2.5

Download an appropriate [JDK 11](https://jdk.java.net/11/) for your operating system. Make sure `JAVA_HOME` 
is properly set to the Java 11 installation directory. 

### Maven

Clone the sample, open it with IntelliJ and import the Maven changes. Compile or run
from the Maven Projects window.