package proyectoBuscador;

public class Tabla {

	int tabla[];
	boolean encontrado = false;
	String ganador;

	public Tabla(int[] tabla) {
		super();
		this.tabla = tabla;
	}

}